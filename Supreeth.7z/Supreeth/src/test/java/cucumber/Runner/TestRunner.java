package cucumber.Runner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@Test
@CucumberOptions(
		features="src/test/java/features/"
		,glue="stepDefinitions"
		,plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/TestReport.html"}
)
public class TestRunner extends AbstractTestNGCucumberTests
{
}