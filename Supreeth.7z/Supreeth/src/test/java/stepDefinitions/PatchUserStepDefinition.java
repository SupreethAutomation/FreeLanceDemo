package stepDefinitions;

import java.io.File;
import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import responseJsonPaths.ResponseJsonPaths;

public class PatchUserStepDefinition implements ResponseJsonPaths
{
}
